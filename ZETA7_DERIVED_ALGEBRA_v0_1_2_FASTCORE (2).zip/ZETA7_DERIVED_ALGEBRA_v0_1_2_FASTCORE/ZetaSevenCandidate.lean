import Mathlib.NumberTheory.Bernoulli
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic

/-!
# Explicit order-seven candidate with the order-five kernel

These are definitions, not claims of positivity, degree, or normalization growth.
The matrix uses D_(3n)^6 / D_(40n), not the D_(3n)^8 kernel from the uploaded PDF.
Both the integration variable and output indeterminate use Polynomial Q as a
representation; muX explicitly maps a numerator in t to a polynomial in X.
No result from Apery/Zeta5 or the uploaded Zeta7 paper is imported.
-/

set_option autoImplicit false
noncomputable section
open Polynomial Finset

namespace ZetaSevenCandidate

/-- D_m(t) = product (t + j^2), 1 <= j <= m. -/
def D (m : ℕ) : Polynomial ℚ :=
  ∏ j ∈ Icc 1 m, (X + C ((j : ℚ) ^ 2))

/-- Rational order-seven monomial moments; B_1 = -1/2. -/
def moment7 (e : ℕ) : ℚ :=
  (-1) ^ e * _root_.bernoulli (2 * e + 2) *
    ((2 * (e : ℚ) + 3) * (2 * (e : ℚ) + 4) * (2 * (e : ℚ) + 5) *
      (2 * (e : ℚ) + 6) * (2 * (e : ℚ) + 7)) / 720

def polynomialMoment (P : Polynomial ℚ) : ℚ :=
  P.sum fun e c => c * moment7 e

def harmonic7 (j : ℕ) : ℚ :=
  ∑ v ∈ Icc 1 j, 1 / (v : ℚ) ^ 7

/-- j^6 (X - H_j^(7)) + 1/(2j) - 1/6. Used only for j >= 1. -/
def poleValue7 (j : ℕ) : Polynomial ℚ :=
  C ((j : ℚ) ^ 6) * (X - C (harmonic7 j)) +
    C (1 / (2 * (j : ℚ))) - C (1 / 6)

/-- Termwise polynomial-division / simple-residue definition of mu_X(P/D_K). -/
def muX (K : ℕ) (P : Polynomial ℚ) : Polynomial ℚ :=
  C (polynomialMoment (P /ₘ D K)) +
    ∑ j ∈ Icc 1 K,
      C (P.eval (-(j : ℚ) ^ 2) /
        (derivative (D K)).eval (-(j : ℚ) ^ 2)) * poleValue7 j

def G (n : ℕ) : Matrix (Fin (37 * n)) (Fin (37 * n)) (Polynomial ℚ) :=
  fun i j => muX (40 * n) (D (3 * n) ^ 6 * X ^ ((i : ℕ) + (j : ℕ)))

def delta (n : ℕ) : Polynomial ℚ := (G n).det

/-- The retained order-five factorial normalization, with exponent 12h. -/
def S (n : ℕ) : ℚ :=
  ((40 * n).factorial : ℚ) ^ (2 * (37 * n)) * 4 ^ (37 * n - 1) /
    (((3 * n).factorial : ℚ) ^ (12 * (37 * n)) *
      ∏ i ∈ Icc 1 (37 * n - 1), ((2 * i).factorial : ℚ) ^ 2)

def F (n : ℕ) : Polynomial ℚ := C (S n) * delta n

end ZetaSevenCandidate
