import Mathlib.NumberTheory.LSeries.RiemannZeta
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

/-!
# Generic integer-polynomial irrationality criterion

The denominator-clearing and logarithmic-divergence proof bodies are reused from
ZETA7_MINIMAL_DIVERGENCE_CLOSURE_v0_1_0_FASTCORE, which passed the user's Lean
4.33.0 run. The namespace and documentation are changed; no paper-specific
premise or cutoff is retained.

This file proves an implication. It supplies no construction or growth premise.
-/

set_option autoImplicit false

noncomputable section
open Polynomial Set

namespace ZetaSevenCriterion

/-- Real zeta(7), using the actual Mathlib Riemann zeta function. -/
def zetaSeven : ℝ := (riemannZeta (7 : ℂ)).re

/-- Evaluate an integer polynomial at a real number. -/
def val (p : ℤ[X]) (x : ℝ) : ℝ :=
  p.eval₂ (Int.castRingHom ℝ) x

/-- Exact minimal divergence: arbitrarily far out there are arbitrarily
large values of (-log Q_n(x))/n. This is the limsup +infinity condition,
expressed with ordinary real quantifiers rather than EReal.limsup. -/
def LogDivergence (x : ℝ) (Q : ℕ → ℤ[X]) : Prop :=
  ∀ C : ℝ, ∀ N : ℕ, ∃ n : ℕ,
    N ≤ n ∧ C < -Real.log (val (Q n) x) / (n : ℝ)

/-- Degree bound clears the denominator of an integer-polynomial evaluation.
Proof pattern is from mathlib's proof of pi irrationality. -/
private lemma integer_after_clearing {p : ℤ[X]} (a b : ℤ) {k : ℕ}
    (hp : p.natDegree ≤ k) :
    ∃ z : ℤ, p.eval₂ (Int.castRingHom ℝ) (a / b) * b ^ k = z := by
  rcases eq_or_ne b 0 with rfl | hb
  · rcases k.eq_zero_or_pos with rfl | hk
    · exact ⟨p.coeff 0, by simp⟩
    · exact ⟨0, by simp [hk.ne']⟩
  refine ⟨∑ i ∈ p.support, p.coeff i * a ^ i * b ^ (k - i), ?_⟩
  conv => lhs; rw [← sum_monomial_eq p]
  rw [eval₂_sum, sum, Finset.sum_mul, Int.cast_sum]
  simp only [eval₂_monomial, eq_intCast, div_pow, Int.cast_mul, Int.cast_pow]
  refine Finset.sum_congr rfl (fun i hi => ?_)
  have ik := (le_natDegree_of_mem_supp i hi).trans hp
  rw [mul_assoc, div_mul_comm, ← Int.cast_pow, ← Int.cast_pow, ← Int.cast_pow,
    ← pow_sub_mul_pow b ik, ← Int.cast_div_charZero,
    Int.mul_ediv_cancel _ (pow_ne_zero _ hb), ← mul_assoc,
    mul_right_comm, ← Int.cast_pow]
  exact dvd_mul_left _ _

/-- Any rational real has a representation with positive natural denominator. -/
private lemma rational_rep {x : ℝ} (hx : ¬Irrational x) :
    ∃ (a : ℤ) (b : ℕ), 0 < b ∧ x = (a : ℝ) / (b : ℝ) := by
  classical
  rw [Irrational, not_not, mem_range] at hx
  rcases hx with ⟨q, rfl⟩
  exact ⟨q.num, q.den, q.pos, by exact_mod_cast (Rat.num_div_den _).symm⟩

/-- The key quantitative inequality: for rational a/b and integer p of
natural degree <= k, strict positivity forces
  -log(p(a/b)) <= k*log(b).
This lemma proves the denominator lower bound rather than assuming it. -/
private theorem log_bound_at_rational (p : ℤ[X]) (a : ℤ) (b k : ℕ)
    (hb : 0 < b) (hp : p.natDegree ≤ k)
    (hv : 0 < val p ((a : ℝ) / (b : ℝ))) :
    -Real.log (val p ((a : ℝ) / (b : ℝ))) ≤
      (k : ℝ) * Real.log (b : ℝ) := by
  obtain ⟨z, hz⟩ := integer_after_clearing a (b : ℤ) hp
  have hz' : val p ((a : ℝ) / (b : ℝ)) * (b : ℝ) ^ k = (z : ℝ) := by
    simpa [val] using hz
  have hbR : (0 : ℝ) < (b : ℝ) := by exact_mod_cast hb
  have hpow : 0 < (b : ℝ) ^ k := pow_pos hbR _
  have hzR : (0 : ℝ) < (z : ℝ) := by
    rw [← hz']
    exact mul_pos hv hpow
  have hzZ : 0 < z := by exact_mod_cast hzR
  have hzOne : (1 : ℤ) ≤ z := by omega
  have hone : (1 : ℝ) ≤ val p ((a : ℝ) / (b : ℝ)) * (b : ℝ) ^ k := by
    rw [hz']
    exact_mod_cast hzOne
  have hlog := Real.log_nonneg hone
  rw [Real.log_mul (ne_of_gt hv) (ne_of_gt hpow), Real.log_pow] at hlog
  linarith

/-- Fully proved conditional closure: integrality (by Q : Z[X]), linear
polynomial degree, positivity and superlinear negative-log divergence
imply irrationality of x. An arbitrary start index permits eventual bounds. -/
theorem irrational_of_log_divergence (x : ℝ) (Q : ℕ → ℤ[X])
    (D start : ℕ)
    (hdegree : ∀ n : ℕ, start ≤ n → (Q n).natDegree ≤ D * n)
    (hpositive : ∀ n : ℕ, start ≤ n → 0 < val (Q n) x)
    (hdivergence : LogDivergence x Q) : Irrational x := by
  classical
  by_contra hx
  obtain ⟨a, b, hb, hxrat⟩ := rational_rep hx
  obtain ⟨n, hn, hlarge⟩ :=
    hdivergence ((D : ℝ) * Real.log (b : ℝ)) (max start 1)
  have hnStart : start ≤ n := (le_max_left start 1).trans hn
  have hnOne : 1 ≤ n := (le_max_right start 1).trans hn
  have hnPos : 0 < n := by omega
  have hnR : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hnPos
  have hv : 0 < val (Q n) ((a : ℝ) / (b : ℝ)) := by
    simpa only [hxrat] using hpositive n hnStart
  have hbound := log_bound_at_rational (Q n) a b (D * n) hb
    (hdegree n hnStart) hv
  have hcast : ((D * n : ℕ) : ℝ) * Real.log (b : ℝ) =
      ((D : ℝ) * Real.log (b : ℝ)) * (n : ℝ) := by
    push_cast
    ring
  rw [hcast] at hbound
  have hlarge' :
      (D : ℝ) * Real.log (b : ℝ) <
        -Real.log (val (Q n) ((a : ℝ) / (b : ℝ))) / (n : ℝ) := by
    simpa only [hxrat] using hlarge
  have hstrict := (lt_div_iff₀ hnR).mp hlarge'
  exact (not_lt_of_ge hbound) hstrict

end ZetaSevenCriterion
