import ZetaSevenArchitecture

/-!
# Derived algebraic degree input for the unchanged order-seven candidate

The proof only uses affine dependence on X and the Leibniz determinant formula.
No zeta(5) theorem, integral representation, positivity premise, or growth bound
is used. All statements hold for n = 0 as well as positive n.
-/

set_option autoImplicit false
noncomputable section
open Polynomial Finset

namespace ZetaSevenDegree

private lemma finite_sum_natDegree_le {ι : Type*} (s : Finset ι)
    (f : ι → Polynomial ℚ) (d : ℕ)
    (hf : ∀ i ∈ s, (f i).natDegree ≤ d) :
    (∑ i ∈ s, f i).natDegree ≤ d := by
  classical
  apply Polynomial.natDegree_le_iff_coeff_eq_zero.mpr
  intro k hk
  rw [Polynomial.finsetSum_coeff]
  apply Finset.sum_eq_zero
  intro i hi
  exact Polynomial.coeff_eq_zero_of_natDegree_lt ((hf i hi).trans_lt hk)

private lemma finite_prod_natDegree_le {ι : Type*} (s : Finset ι)
    (f : ι → Polynomial ℚ) :
    (∏ i ∈ s, f i).natDegree ≤ ∑ i ∈ s, (f i).natDegree := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
      rw [Finset.prod_insert hi, Finset.sum_insert hi]
      exact Polynomial.natDegree_mul_le.trans (Nat.add_le_add_left ih _)

/-- Every order-seven pole value is affine, including at the unused index 0. -/
theorem poleValue7_natDegree_le (j : ℕ) :
    (ZetaSevenCandidate.poleValue7 j).natDegree ≤ 1 := by
  unfold ZetaSevenCandidate.poleValue7
  apply (Polynomial.natDegree_sub_le _ _).trans
  apply max_le
  · apply Polynomial.natDegree_add_le_of_degree_le
    · exact (Polynomial.natDegree_C_mul_le _ _).trans
        (Polynomial.natDegree_X_sub_C_le _)
    · -- Keep C(q) intact: unrestricted simp expands rational inverses/products.
      simpa only [Polynomial.natDegree_C] using (Nat.zero_le 1)
  · simpa only [Polynomial.natDegree_C] using (Nat.zero_le 1)

/-- The rational-function numerator may be arbitrary: the output is affine. -/
theorem muX_natDegree_le (K : ℕ) (P : Polynomial ℚ) :
    (ZetaSevenCandidate.muX K P).natDegree ≤ 1 := by
  unfold ZetaSevenCandidate.muX
  apply Polynomial.natDegree_add_le_of_degree_le
  · simpa only [Polynomial.natDegree_C] using (Nat.zero_le 1)
  · apply finite_sum_natDegree_le
    intro j hj
    exact (Polynomial.natDegree_C_mul_le _ _).trans (poleValue7_natDegree_le j)

/-- All entries of the specific candidate matrix have degree at most one. -/
theorem G_entry_natDegree_le (n : ℕ) (i j : Fin (37 * n)) :
    (ZetaSevenCandidate.G n i j).natDegree ≤ 1 := by
  exact muX_natDegree_le _ _

/-- A general Leibniz-formula bound for a square matrix with affine entries. -/
theorem affine_det_natDegree_le {ι : Type*} [Fintype ι] [DecidableEq ι]
    (M : Matrix ι ι (Polynomial ℚ))
    (hM : ∀ i j, (M i j).natDegree ≤ 1) :
    M.det.natDegree ≤ Fintype.card ι := by
  classical
  rw [Matrix.det_apply]
  apply finite_sum_natDegree_le
  intro σ hσ
  have hprod : (∏ i : ι, M (σ i) i).natDegree ≤ Fintype.card ι := by
    calc
      (∏ i : ι, M (σ i) i).natDegree
          ≤ ∑ i : ι, (M (σ i) i).natDegree := finite_prod_natDegree_le _ _
      _ ≤ ∑ _i : ι, (1 : ℕ) := Finset.sum_le_sum (fun i _ => hM (σ i) i)
      _ = Fintype.card ι := by simp
  rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hs | hs
  · simpa only [hs, one_smul] using hprod
  · simpa only [hs, Units.neg_smul, one_smul, Polynomial.natDegree_neg] using hprod

/-- The determinant bound is independent of its unknown analytic behavior. -/
theorem delta_natDegree_le (n : ℕ) :
    (ZetaSevenCandidate.delta n).natDegree ≤ 37 * n := by
  simpa only [ZetaSevenCandidate.delta, Fintype.card_fin] using
    affine_det_natDegree_le (ZetaSevenCandidate.G n) (G_entry_natDegree_le n)

/-- Unconditional proof of the entire degree input required by the endpoint. -/
theorem degree_F (n : ℕ) :
    (ZetaSevenCandidate.F n).natDegree ≤ 37 * n := by
  exact (Polynomial.natDegree_C_mul_le _ _).trans (delta_natDegree_le n)

/-- DegreeInput is now a supplied theorem, not a hypothesis argument. -/
theorem degree_input :
    ZetaSevenArchitecture.DegreeInput ZetaSevenCandidate.F := by
  exact ⟨0, fun n _ => degree_F n⟩

/-- The explicit factorial scalar is strictly positive; this does not prove
positivity of the determinant or its value at zeta(7). -/
theorem S_positive (n : ℕ) : 0 < ZetaSevenCandidate.S n := by
  unfold ZetaSevenCandidate.S
  apply div_pos
  · apply mul_pos
    · apply pow_pos
      exact_mod_cast Nat.factorial_pos (40 * n)
    · positivity
  · apply mul_pos
    · apply pow_pos
      exact_mod_cast Nat.factorial_pos (3 * n)
    · apply Finset.prod_pos
      intro i hi
      apply pow_pos
      exact_mod_cast Nat.factorial_pos (2 * i)

end ZetaSevenDegree
