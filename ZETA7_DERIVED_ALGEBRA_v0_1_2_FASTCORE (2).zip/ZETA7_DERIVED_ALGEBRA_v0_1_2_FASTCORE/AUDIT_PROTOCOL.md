# Audit protocol

1. Confirm the three inherited source hashes match the previous archive.
2. Compile the six modules in run.cmd's dependency order.
3. Audit the definitions of zetaSeven and F.
4. Inspect every printed axiom dependency: no sorryAx or unexpected theorem axiom.
5. Check degree_F and degree_input have no mathematical hypothesis arguments.
6. Check positive_integer_multiple does not assume integrality of its input.
7. Check the fixed sequences in integer_normalization_exists have no growth claim.
8. Check the reduced endpoint has no DEGREE_PREMISE but still has analytic,
   arithmetic, and gap hypotheses. Do not infer these hypotheses from the audit.

The source escape scan is only a convenience filter; the full printed axiom
lists and theorem signatures are the substantive audit information.
