# References and provenance

The local input archive is ZETA7_ZETA5_ARCHITECTURE_v0_1_0_FASTCORE.zip.
The user supplied a passing native Lean 4.33.0 run for that archive.

Mathlib APIs checked against public primary source (2026-10-20):
- https://raw.githubusercontent.com/leanprover-community/mathlib4/v4.33.0/Mathlib/Algebra/Polynomial/Basic.lean
  Polynomial.induction_on', C_mul_monomial.
- https://raw.githubusercontent.com/leanprover-community/mathlib4/v4.33.0/Mathlib/Algebra/Polynomial/Degree/Defs.lean
  natDegree_add_le_of_degree_le, natDegree_sub_le, natDegree_mul_le.
- https://raw.githubusercontent.com/leanprover-community/mathlib4/v4.33.0/Mathlib/Algebra/Polynomial/Degree/Lemmas.lean
  natDegree_le_iff_coeff_eq_zero, natDegree_C_mul_le.
- https://raw.githubusercontent.com/leanprover-community/mathlib4/master/Mathlib/LinearAlgebra/Matrix/Determinant/Basic.lean
  Matrix.det_apply (Leibniz expansion).

External zeta(5) results are not imported. No uploaded-paper claims are used.

## v0.1.1 API check

- https://raw.githubusercontent.com/leanprover-community/mathlib4/v4.33.0/Mathlib/Algebra/Polynomial/Degree/Defs.lean
  Polynomial.natDegree_C: natDegree (C a) = 0.
- https://raw.githubusercontent.com/leanprover-community/mathlib4/v4.33.0/Mathlib/Algebra/Polynomial/Basic.lean
  C is a ring homomorphism; C_mul collects a product of constants.

## v0.1.2 API check

- https://raw.githubusercontent.com/leanprover-community/mathlib4/v4.33.0/Mathlib/Data/Nat/Cast/Order/Ring.lean
  Nat.cast_pos {α} [Semiring α] [PartialOrder α] [IsOrderedRing α]
    [Nontrivial α] {n : ℕ} : (0 : α) < n ↔ 0 < n.
  Instantiated here with α := ℚ and used through `.mpr`.
