# ZETA7_DERIVED_ALGEBRA_v0_1_2_FASTCORE

## Scope

Minimal compile-error patch to v0.1.1. The candidate, criterion, original
architecture, degree proofs, reduced closure, theorem signatures, and remaining
premises are unchanged. The native Lean 4.33.0 cached-Mathlib FASTCORE runner
is unchanged except for its displayed package name.

## Fix v0.1.2

The user's v0.1.1 run compiled Criterion, Candidate, Architecture, and Degree.
It stopped at ZetaSevenNormalization.lean:64. The goal still displayed the
application `(fun n => (d n : ℚ)) n`, and `exact_mod_cast` did not transport the
natural-number positivity fact to that rational-valued target.

The new proof makes the target explicit and uses the cast lemma directly:

```lean
  change (0 : ℚ) < (d n : ℚ)
  exact (Nat.cast_pos (α := ℚ)).mpr (hspec n).1
```

There are no new mathematical assumptions and no additional imports.
Audit.lean adds two regression examples for this cast and its conjunction
context. The earlier degree regression examples remain present.

## Verification status

- Prior user-reported v0.1.1 compilation: Criterion, Candidate, Architecture,
  and Degree PASS; Normalization FAIL; ReducedClosure and Audit not reached.
- These four passed module files are preserved byte-for-byte.
- New proof uses the Mathlib v4.33.0 Nat.cast_pos declaration.
- New revision has NOT been Lean-compiled in the assistant container.
- Archive integrity, SHA-256 manifest, unchanged-file checks, and static proof
  escape checks were performed. These are not kernel verification.
- Run run.cmd to compile all six modules and the full audit.

## Windows CMD

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETA7_DERIVED_ALGEBRA_v0_1_2_FASTCORE.zip" && call "ZETA7_DERIVED_ALGEBRA_v0_1_2_FASTCORE\run.cmd"
```

The runner uses the existing native Lean 4.33.0 executable, existing Mathlib
cache, and the same default of 16 jobs. No Lake, network, Python, PowerShell,
WSL, or umbrella Mathlib import is used by the runner.

## Mathematical boundary

The degree bound and positivity of the factorial scalar are proved by the
unchanged degree source, which passed in the user's v0.1.1 run. The normalization
source proves existence of a fixed positive rational multiplier sequence making
integer polynomials, but does NOT assert a sufficiently small multiplier.

The reduced endpoint retains exactly:

- AnalyticInput, including determinant positivity and its growth bound;
- ArithmeticInput, including a growth bound with fixed normalization witnesses;
- the strict condition A + U < 0.

The actual order-seven integral representation, successful analytic and
arithmetic bounds, negative gap, and unconditional irrationality of zeta(7)
are NOT established by this patch.
