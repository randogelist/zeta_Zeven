import ZetaSevenReducedClosure

/-! Full signatures and axiom dependencies; estimates remain hypotheses. -/

-- Regression 1: the original scalar expression, before unrestricted simp.
example (j : ℕ) :
    (Polynomial.C (1 / (2 * (j : ℚ))) : Polynomial ℚ).natDegree ≤ 1 := by
  simpa only [Polynomial.natDegree_C] using (Nat.zero_le 1)

-- Regression 2: the product form displayed in the failed v0.1.0 goal.
example (j : ℕ) :
    (Polynomial.C ((j : ℚ)⁻¹) * Polynomial.C ((2 : ℚ)⁻¹)).natDegree ≤ 1 := by
  rw [← Polynomial.C_mul]
  simpa only [Polynomial.natDegree_C] using (Nat.zero_le 1)

-- Regression 3: positivity under the lambda application from v0.1.1.
example (d : ℕ → ℕ) (n : ℕ) (h : 0 < d n) :
    (0 : ℚ) < (fun k : ℕ => (d k : ℚ)) n := by
  change (0 : ℚ) < (d n : ℚ)
  exact (Nat.cast_pos (α := ℚ)).mpr h

-- Regression 4: positivity as the first component of a conjunction witness.
example (d : ℕ → ℕ) (P : ℕ → Prop)
    (hspec : ∀ n, 0 < d n ∧ P n) :
    ∃ m : ℕ → ℚ, ∀ n, 0 < m n ∧ P n := by
  refine ⟨fun n => (d n : ℚ), ?_⟩
  intro n
  refine ⟨?_, (hspec n).2⟩
  change (0 : ℚ) < (d n : ℚ)
  exact (Nat.cast_pos (α := ℚ)).mpr (hspec n).1

#print ZetaSevenCriterion.zetaSeven
#print ZetaSevenCandidate.G
#print ZetaSevenCandidate.F
#print ZetaSevenArchitecture.AnalyticInput
#print ZetaSevenArchitecture.ArithmeticInput

#print axioms ZetaSevenDegree.poleValue7_natDegree_le
#print axioms ZetaSevenDegree.muX_natDegree_le
#print axioms ZetaSevenDegree.G_entry_natDegree_le
#print axioms ZetaSevenDegree.affine_det_natDegree_le
#print axioms ZetaSevenDegree.delta_natDegree_le
#print axioms ZetaSevenDegree.degree_F
#print axioms ZetaSevenDegree.degree_input
#print axioms ZetaSevenDegree.S_positive
#print axioms ZetaSevenNormalization.positive_integer_multiple
#print axioms ZetaSevenNormalization.integer_normalization_exists
#print axioms ZetaSevenNormalization.normalized_degree_le
#print axioms ZetaSevenReducedClosure.ZETA7_DEGREE_DISCHARGED
#print axioms ZetaSevenReducedClosure.candidate_quadratic_estimate

#check ZetaSevenDegree.degree_F
#check ZetaSevenNormalization.integer_normalization_exists
#check ZetaSevenReducedClosure.ZETA7_DEGREE_DISCHARGED
#print ZetaSevenDegree.degree_input
#print ZetaSevenReducedClosure.ZETA7_DEGREE_DISCHARGED
#eval "AUDIT_END=DEGREE_DERIVED_NORMALIZATION_EXISTENCE_DERIVED_GROWTH_OPEN"
