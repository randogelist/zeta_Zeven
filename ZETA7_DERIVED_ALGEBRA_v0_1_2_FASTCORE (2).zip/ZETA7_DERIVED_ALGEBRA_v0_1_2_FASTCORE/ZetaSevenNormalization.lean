import ZetaSevenDegree

/-!
# Exact integer normalization exists; no growth estimate is asserted

A rational polynomial has a positive integer multiple with integer
coefficients. The proof uses polynomial induction and denominator clearing.
This supplies the finite algebraic part of the arithmetic input, not its
asymptotic inequality. A normalizer supplied here is not claimed primitive,
optimal, or sufficiently small for irrationality.
-/

set_option autoImplicit false
noncomputable section
open Polynomial

namespace ZetaSevenNormalization

/-- Positive denominator clearing for an arbitrary rational polynomial. -/
theorem positive_integer_multiple (P : Polynomial ℚ) :
    ∃ d : ℕ, ∃ Q : Polynomial ℤ,
      0 < d ∧ Q.map (Int.castRingHom ℚ) = C (d : ℚ) * P := by
  classical
  induction P using Polynomial.induction_on' with
  | add p q hp hq =>
      obtain ⟨a, P, ha, hP⟩ := hp
      obtain ⟨b, Q, hb, hQ⟩ := hq
      refine ⟨a * b, C (b : ℤ) * P + C (a : ℤ) * Q, Nat.mul_pos ha hb, ?_⟩
      simp only [Polynomial.map_add, Polynomial.map_mul, Polynomial.map_C, hP, hQ]
      change C (b : ℚ) * (C (a : ℚ) * p) + C (a : ℚ) * (C (b : ℚ) * q) =
        C ((a * b : ℕ) : ℚ) * (p + q)
      rw [Nat.cast_mul, Polynomial.C_mul]
      ring
  | monomial k c =>
      refine ⟨c.den, monomial k c.num, c.pos, ?_⟩
      have hd : (c.den : ℚ) ≠ 0 := by exact_mod_cast c.den_nz
      have hc : (c.den : ℚ) * c = (c.num : ℚ) := by
        have h : (c.num : ℚ) = c * (c.den : ℚ) :=
          (div_eq_iff hd).mp (Rat.num_div_den c)
        simpa only [mul_comm] using h.symm
      rw [Polynomial.map_monomial]
      change monomial k (c.num : ℚ) = C (c.den : ℚ) * monomial k c
      rw [Polynomial.C_mul_monomial, hc]

/-- One fixed pair of sequences exists, independently of any epsilon or
later asymptotic claim. No estimate for the sizes of these multipliers. -/
theorem integer_normalization_exists :
    ∃ m : ℕ → ℚ, ∃ Q : ℕ → Polynomial ℤ,
      ∀ n : ℕ, 0 < m n ∧
        (Q n).map (Int.castRingHom ℚ) = C (m n) * ZetaSevenCandidate.F n := by
  classical
  let d : ℕ → ℕ := fun n =>
    Classical.choose (positive_integer_multiple (ZetaSevenCandidate.F n))
  let Q : ℕ → Polynomial ℤ := fun n =>
    Classical.choose (Classical.choose_spec
      (positive_integer_multiple (ZetaSevenCandidate.F n)))
  have hspec (n : ℕ) : 0 < d n ∧
      (Q n).map (Int.castRingHom ℚ) = C (d n : ℚ) * ZetaSevenCandidate.F n := by
    exact Classical.choose_spec (Classical.choose_spec
      (positive_integer_multiple (ZetaSevenCandidate.F n)))
  refine ⟨fun n => (d n : ℚ), Q, ?_⟩
  intro n
  refine ⟨?_, (hspec n).2⟩
  change (0 : ℚ) < (d n : ℚ)
  exact (Nat.cast_pos (α := ℚ)).mpr (hspec n).1

/-- Every positive rational normalization of the candidate preserves its
proved degree bound; the multiplier is not forced to be the choice above. -/
theorem normalized_degree_le (n : ℕ) (m : ℚ) (Q : Polynomial ℤ)
    (hm : 0 < m)
    (hmap : Q.map (Int.castRingHom ℚ) = C m * ZetaSevenCandidate.F n) :
    Q.natDegree ≤ 37 * n := by
  have hmapdegree : (Q.map (Int.castRingHom ℚ)).natDegree = Q.natDegree :=
    Polynomial.natDegree_map_eq_of_injective Int.cast_injective Q
  rw [← hmapdegree, hmap, Polynomial.natDegree_C_mul (ne_of_gt hm)]
  exact ZetaSevenDegree.degree_F n

end ZetaSevenNormalization
