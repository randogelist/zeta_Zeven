@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "PACKAGE=ZETA7_DERIVED_ALGEBRA_v0_1_2_FASTCORE"
set "RUN_STEP=initializing"
pushd "%~dp0"
if errorlevel 1 (
  echo RUN=FAIL
  echo FAILED_STAGE=package_directory
  exit /b 2
)

echo PACKAGE=%PACKAGE%
echo RUNNER=NATIVE_WINDOWS_LEAN_433_FASTCORE
echo CACHE_REUSE=YES
echo FULL_MATHLIB_UMBRELLA_IMPORT=NO
echo LAKE=NOT_USED
echo NETWORK=NOT_USED
echo PYTHON=NOT_USED
echo POWERSHELL=NOT_USED
echo WSL=NOT_USED

rem Reuse the previously tested native Lean executable, never an elan shim.
set "TOOLCHAIN=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0"
if defined ELAN_HOME set "TOOLCHAIN=%ELAN_HOME%\toolchains\leanprover--lean4---v4.33.0"
set "LEAN_EXE=%TOOLCHAIN%\bin\lean.exe"
if defined AWPIRH_LEAN_EXE set "LEAN_EXE=%AWPIRH_LEAN_EXE%"
set "RUN_STEP=checking_native_lean"
if not exist "%LEAN_EXE%" goto missing_lean
"%LEAN_EXE%" --version > lean-version.log 2>&1
if errorlevel 1 goto failed
findstr /L /C:"version 4.33.0" lean-version.log >nul
if errorlevel 1 goto wrong_version
echo LEAN_EXE_FOUND=PASS
type lean-version.log

rem Fixed cache root; override only if user explicitly supplies it.
set "RUN_STEP=locating_cached_mathlib"
set "CACHE_ROOT=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
if defined MATHLIB_CACHE_ROOT set "CACHE_ROOT=%MATHLIB_CACHE_ROOT%"
set "MATHLIB_ROOT=%CACHE_ROOT%\.lake\packages\mathlib"
if not exist "%MATHLIB_ROOT%\.lake\build\lib\lean\Mathlib\Tactic\NormNum.olean" set "MATHLIB_ROOT=%CACHE_ROOT%"
set "MATHLIB_LIB=%MATHLIB_ROOT%\.lake\build\lib\lean"
if not exist "%MATHLIB_LIB%\Mathlib\Tactic\NormNum.olean" goto missing_cache
if not exist "%TOOLCHAIN%\lib\lean\Init.olean" goto missing_lean

echo CACHE_ROOT="%CACHE_ROOT%"
echo MINIMAL_MATHLIB_CACHE=READY
set "RUN_STEP=preparing_offline_search_path"
if not exist "_native_build" mkdir "_native_build"
if not exist "_native_build" goto failed
set "BUILD_DIR=%CD%\_native_build"
set "LEAN_PATH=%BUILD_DIR%;%MATHLIB_LIB%"
for /D %%D in ("%CACHE_ROOT%\.lake\packages\*") do call :append_cache "%%~fD"
for /D %%D in ("%MATHLIB_ROOT%\.lake\packages\*") do call :append_cache "%%~fD"
if exist "%CACHE_ROOT%\.lake\build\lib\lean" set "LEAN_PATH=%LEAN_PATH%;%CACHE_ROOT%\.lake\build\lib\lean"
set "LEAN_PATH=%LEAN_PATH%;%TOOLCHAIN%\lib\lean"
set "LEAN_SYSROOT=%TOOLCHAIN%"
set "PATH=%TOOLCHAIN%\bin;%PATH%"
if not defined LEAN_JOBS set "LEAN_JOBS=16"
set "LEAN_NUM_THREADS=%LEAN_JOBS%"
echo LEAN_JOBS=%LEAN_JOBS%
echo CACHE_PATH_SETUP=PASS

set "RUN_STEP=checking_module_cache"
for %%M in (NumberTheory\Bernoulli Algebra\Polynomial\Div Algebra\Polynomial\Derivative LinearAlgebra\Matrix\Determinant\Basic RingTheory\Polynomial\Tower Algebra\Polynomial\Degree\Lemmas) do (
  if not exist "%MATHLIB_LIB%\Mathlib\%%M.olean" (
    echo MISSING_CACHED_MODULE=Mathlib.%%M
    set "RUN_EXIT=4"
    goto failed
  )
)
echo CONSTRUCTION_MODULE_CACHE=READY

set "RUN_STEP=scanning_source"
findstr /N /I /R /C:"^[ ]*sorry" /C:"^[ ]*admit" /C:"^[ ]*axiom " /C:"^[ ]*unsafe " ZetaSevenCriterion.lean ZetaSevenCandidate.lean ZetaSevenArchitecture.lean ZetaSevenDegree.lean ZetaSevenNormalization.lean ZetaSevenReducedClosure.lean Audit.lean > proof-scan.log 2>&1
if not errorlevel 1 goto source_fail
echo PROOF_ESCAPE_SCAN=PASS

call :compile ZetaSevenCriterion
if errorlevel 1 goto failed
call :compile ZetaSevenCandidate
if errorlevel 1 goto failed
call :compile ZetaSevenArchitecture
if errorlevel 1 goto failed
call :compile ZetaSevenDegree
if errorlevel 1 goto failed
call :compile ZetaSevenNormalization
if errorlevel 1 goto failed
call :compile ZetaSevenReducedClosure
if errorlevel 1 goto failed

set "RUN_STEP=checking_axioms"
echo AUDIT_START=Audit.lean
"%LEAN_EXE%" -j%LEAN_JOBS% "Audit.lean" > lean-audit.log 2>&1
set "RUN_EXIT=%errorlevel%"
type lean-audit.log
if not "%RUN_EXIT%"=="0" goto failed
findstr /L /C:"sorryAx" lean-audit.log >nul
if not errorlevel 1 goto sorry_fail
echo SORRYAX=NONE
echo AUDIT_PASS=Audit.lean
echo CONDITIONAL_ARCHITECTURE=PROVED
echo SPECIFIC_DETERMINANT=DEFINED
echo ACTUAL_RIEMANN_ZETA_7_BINDING=YES
echo DEGREE_BOUND=PROVED
echo DEGREE_PREMISE=DISCHARGED
echo FACTORIAL_SCALAR_POSITIVE=PROVED
echo INTEGER_NORMALIZATION_EXISTS=PROVED
echo NORMALIZED_DEGREE_BOUND=PROVED
echo REMAINING_ESTIMATE_BLOCKS=2
echo STRICT_GAP_PREMISE=EXPLICIT_UNPROVED
echo ANALYTIC_PREMISE=EXPLICIT_UNPROVED
echo DETERMINANT_POSITIVITY=STILL_IN_ANALYTIC_PREMISE
echo ARITHMETIC_PREMISE=GROWTH_WITH_FIXED_WITNESSES_UNPROVED
echo NORMALIZER_GROWTH=NOT_PROVED
echo NO_OPTIMAL_NORMALIZER_ASSERTED=YES
echo QUADRATIC_DECAY=DERIVED_CONDITIONALLY
echo LOG_DIVERGENCE=DERIVED_CONDITIONALLY
echo PAPER_THEOREM_1_2=NOT_USED
echo UNCONDITIONAL_IRRATIONALITY=NOT_PROVED
echo MATHEMATICAL_AUDIT=DEGREE_ELIMINATED_ESTIMATES_STILL_OPEN
echo PROJECT_BUILD=PASS
echo RUN=PASS
popd
endlocal & exit /b 0

:compile
set "RUN_STEP=compiling_%~1"
echo COMPILE_START=%~1.lean
"%LEAN_EXE%" -j%LEAN_JOBS% -o "%BUILD_DIR%\%~1.olean" "%~1.lean" > "%~1-compile.log" 2>&1
set "RUN_EXIT=%errorlevel%"
type "%~1-compile.log"
if not "%RUN_EXIT%"=="0" exit /b %RUN_EXIT%
if not exist "%BUILD_DIR%\%~1.olean" (
  set "RUN_EXIT=1"
  exit /b 1
)
echo COMPILE_PASS=%~1.lean
exit /b 0

:append_cache
if exist "%~1\.lake\build\lib\lean" set "LEAN_PATH=%LEAN_PATH%;%~1\.lake\build\lib\lean"
exit /b 0

:missing_lean
echo LEAN_EXE_FOUND=FAIL
echo EXPECTED_NATIVE_LEAN="%LEAN_EXE%"
set "RUN_EXIT=2"
goto failed
:wrong_version
echo LEAN_VERSION_CHECK=FAIL_EXPECTED_4.33.0
set "RUN_EXIT=3"
goto failed
:missing_cache
echo MINIMAL_MATHLIB_CACHE=NOT_FOUND
echo EXPECTED_OLEAN="%MATHLIB_LIB%\Mathlib\Tactic\NormNum.olean"
echo CACHE_DOWNLOAD=NOT_ATTEMPTED
set "RUN_EXIT=4"
goto failed
:source_fail
type proof-scan.log
echo PROOF_ESCAPE_SCAN=FAIL
set "RUN_EXIT=5"
goto failed
:sorry_fail
echo SORRYAX=FOUND
set "RUN_EXIT=6"
goto failed
:failed
if not defined RUN_EXIT set "RUN_EXIT=1"
echo PROJECT_BUILD=FAIL
echo FAILED_STAGE=%RUN_STEP%
echo EXIT_CODE=%RUN_EXIT%
echo CHECK_LOGS=ZetaSevenCriterion-compile.log,ZetaSevenCandidate-compile.log,ZetaSevenArchitecture-compile.log,ZetaSevenDegree-compile.log,ZetaSevenNormalization-compile.log,ZetaSevenReducedClosure-compile.log,lean-audit.log
popd
endlocal & exit /b %RUN_EXIT%
