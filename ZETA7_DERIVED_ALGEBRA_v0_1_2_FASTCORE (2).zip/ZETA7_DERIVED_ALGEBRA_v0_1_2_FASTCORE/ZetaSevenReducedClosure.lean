import ZetaSevenNormalization

/-!
# Reduced endpoint: the degree premise has been discharged

The original architecture and candidate definitions are unchanged.
The analytic input (including determinant positivity), the arithmetic growth
input, and the negative-gap condition remain explicit, unproved hypotheses.
Existence of some integer normalization does not establish ArithmeticInput.
-/

set_option autoImplicit false
noncomputable section
open ZetaSevenArchitecture ZetaSevenCriterion

namespace ZetaSevenReducedClosure

/-- Unlike the previous endpoint, this theorem has no DEGREE_PREMISE. -/
theorem ZETA7_DEGREE_DISCHARGED
    (A U : ℝ)
    (ANALYTIC_PREMISE : AnalyticInput ZetaSevenCandidate.F zetaSeven U)
    (ARITHMETIC_PREMISE : ArithmeticInput ZetaSevenCandidate.F A)
    (GAP_PREMISE : A + U < 0) :
    Irrational zetaSeven := by
  exact irrational_of_three_inputs ZetaSevenCandidate.F zetaSeven A U
    ZetaSevenDegree.degree_input ANALYTIC_PREMISE ARITHMETIC_PREMISE GAP_PREMISE

/-- Quadratic decay also no longer needs an assumed degree input. -/
theorem candidate_quadratic_estimate
    (A U : ℝ)
    (ANALYTIC_PREMISE : AnalyticInput ZetaSevenCandidate.F zetaSeven U)
    (ARITHMETIC_PREMISE : ArithmeticInput ZetaSevenCandidate.F A)
    (GAP_PREMISE : A + U < 0) :
    ∃ c : ℝ, 0 < c ∧ c = -800 * (A + U) ∧
      QuadraticEstimate ZetaSevenCandidate.F zetaSeven c := by
  exact three_inputs_quadratic_estimate ZetaSevenCandidate.F zetaSeven A U
    ZetaSevenDegree.degree_input ANALYTIC_PREMISE ARITHMETIC_PREMISE GAP_PREMISE

end ZetaSevenReducedClosure
