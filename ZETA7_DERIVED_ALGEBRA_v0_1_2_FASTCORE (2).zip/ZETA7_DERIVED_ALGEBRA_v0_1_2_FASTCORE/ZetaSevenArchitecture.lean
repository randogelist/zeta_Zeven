import ZetaSevenCriterion
import ZetaSevenCandidate
import Mathlib.RingTheory.Polynomial.Tower
import Mathlib.Algebra.Polynomial.Degree.Lemmas

/-!
# Three inputs plus a strict gap imply irrationality of the actual zeta(7)

The generic proof is independent of the particular determinant. The endpoint
instantiates it with ZetaSevenCandidate.F, so all assumptions concern exactly
one explicitly defined family. No unrelated family can be substituted there.

Inputs: degree, analytic positivity/growth, integer normalization/growth, gap.
Derived: a quadratic logarithmic bound, exponential decay, log divergence,
then irrationality. The inputs themselves are NOT proved by this module.

Growth bounds use epsilon quantifiers rather than a potentially ambiguous
real-valued limsup or an unspecified little-o term. A and U are free constants;
no previously proposed numerical estimate is asserted to satisfy the gap.
-/

set_option autoImplicit false
noncomputable section
open Polynomial
open ZetaSevenCriterion

namespace ZetaSevenArchitecture

def Kr (n : ℕ) : ℝ := 40 * (n : ℝ)

/-- Input 1: eventual linear degree bound. Equality is unnecessary. -/
def DegreeInput (F : ℕ → Polynomial ℚ) : Prop :=
  ∃ start : ℕ, ∀ n : ℕ, start ≤ n → (F n).natDegree ≤ 37 * n

/-- Input 2: positivity and analytic quadratic upper bound, on the same F. -/
def AnalyticInput (F : ℕ → Polynomial ℚ) (x U : ℝ) : Prop :=
  ∀ ε : ℝ, 0 < ε → ∃ start : ℕ, ∀ n : ℕ, start ≤ n →
    0 < aeval x (F n) ∧
      Real.log (aeval x (F n)) ≤ (U + ε) * Kr n ^ 2

/-- Input 3: one fixed normalizer and one fixed integer family, shared by
all epsilon estimates. The map equality is a polynomial identity, not only
an equality at x. No primitive-normalization condition is required. -/
def ArithmeticInput (F : ℕ → Polynomial ℚ) (A : ℝ) : Prop :=
  ∃ m : ℕ → ℚ, ∃ Q : ℕ → Polynomial ℤ,
    ∀ ε : ℝ, 0 < ε → ∃ start : ℕ, ∀ n : ℕ, start ≤ n →
      0 < m n ∧
      (Q n).map (Int.castRingHom ℚ) = C (m n) * F n ∧
      Real.log (m n : ℝ) ≤ (A + ε) * Kr n ^ 2

/-- The output still records the rational-multiple identity, preventing
loss of the link to F during the closure argument. -/
def QuadraticEstimate (F : ℕ → Polynomial ℚ) (x c : ℝ) : Prop :=
  ∃ Q : ℕ → Polynomial ℤ, ∃ start : ℕ, ∀ n : ℕ, start ≤ n →
    (∃ r : ℚ, 0 < r ∧ (Q n).map (Int.castRingHom ℚ) = C r * F n) ∧
    (Q n).natDegree ≤ 37 * n ∧
    0 < aeval x (Q n) ∧
    Real.log (aeval x (Q n)) ≤ -c * (n : ℝ) ^ 2

lemma int_aeval_eq_val (p : Polynomial ℤ) (x : ℝ) :
    aeval x p = val p x := by
  simp only [aeval_def, val, algebraMap_int_eq]

/-- Core combination theorem. For delta = -(A+U), the two errors delta/4
leave log Q_n(x) <= -(delta/2) K^2 = -800 delta n^2. -/
theorem three_inputs_quadratic_estimate
    (F : ℕ → Polynomial ℚ) (x A U : ℝ)
    (hdegree : DegreeInput F)
    (hanalytic : AnalyticInput F x U)
    (harithmetic : ArithmeticInput F A)
    (hgap : A + U < 0) :
    ∃ c : ℝ, 0 < c ∧ c = -800 * (A + U) ∧ QuadraticEstimate F x c := by
  classical
  let δ : ℝ := -(A + U)
  have hδ : 0 < δ := by dsimp [δ]; linarith
  have hε : 0 < δ / 4 := by positivity
  obtain ⟨nd, hd⟩ := hdegree
  obtain ⟨nf, hf⟩ := hanalytic (δ / 4) hε
  obtain ⟨m, Q, hm⟩ := harithmetic
  obtain ⟨na, ha⟩ := hm (δ / 4) hε
  refine ⟨800 * δ, by positivity, ?_, Q, max (max nd nf) (max na 1), ?_⟩
  · dsimp [δ]
    ring
  · intro n hn
    have hnd : nd ≤ n := by omega
    have hnf : nf ≤ n := by omega
    have hna : na ≤ n := by omega
    obtain ⟨hmpos, hmap, hmlog⟩ := ha n hna
    obtain ⟨hFpos, hFlog⟩ := hf n hnf
    have hmposR : (0 : ℝ) < (m n : ℝ) := by exact_mod_cast hmpos
    have hQeval : aeval x (Q n) = (m n : ℝ) * aeval x (F n) := by
      rw [← aeval_map_algebraMap ℚ x (Q n)]
      simp only [algebraMap_int_eq, hmap, map_mul, aeval_C]
      rfl
    have hQdegree : (Q n).natDegree ≤ 37 * n := by
      have hmapdegree : ((Q n).map (Int.castRingHom ℚ)).natDegree =
          (Q n).natDegree :=
        natDegree_map_eq_of_injective Int.cast_injective (Q n)
      rw [← hmapdegree, hmap, natDegree_C_mul (ne_of_gt hmpos)]
      exact hd n hnd
    have hQpos : 0 < aeval x (Q n) := by
      rw [hQeval]
      exact mul_pos hmposR hFpos
    refine ⟨⟨m n, hmpos, hmap⟩, hQdegree, hQpos, ?_⟩
    rw [hQeval, Real.log_mul (ne_of_gt hmposR) (ne_of_gt hFpos)]
    calc
      Real.log (m n : ℝ) + Real.log (aeval x (F n))
          ≤ (A + δ / 4) * Kr n ^ 2 + (U + δ / 4) * Kr n ^ 2 :=
        add_le_add hmlog hFlog
      _ = -(800 * δ) * (n : ℝ) ^ 2 := by
        dsimp [Kr, δ]
        ring

/-- A positive quadratic logarithmic decay rate implies the earlier
minimal divergence condition. Divergence is a conclusion, not an input. -/
theorem quadratic_log_implies_divergence
    (x : ℝ) (Q : ℕ → Polynomial ℤ) (c : ℝ) (hc : 0 < c) (start : ℕ)
    (hlog : ∀ n : ℕ, start ≤ n →
      Real.log (val (Q n) x) ≤ -c * (n : ℝ) ^ 2) :
    LogDivergence x Q := by
  intro C N
  obtain ⟨k, hk⟩ := exists_nat_gt (C / c)
  let n : ℕ := max (max N start) (max 1 k)
  have hnN : N ≤ n := by dsimp [n]; omega
  have hnStart : start ≤ n := by dsimp [n]; omega
  have hnk : k ≤ n := by dsimp [n]; omega
  have hnPosNat : 0 < n := by dsimp [n]; omega
  have hnPos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hnPosNat
  have hkReal : (k : ℝ) ≤ (n : ℝ) := by exact_mod_cast hnk
  have hC : C < c * (n : ℝ) := by
    have hfrac : C / c < (n : ℝ) := lt_of_lt_of_le hk hkReal
    have hmult := (div_lt_iff₀ hc).mp hfrac
    nlinarith
  have hMul : C * (n : ℝ) < c * (n : ℝ) ^ 2 := by
    calc
      C * (n : ℝ) < (c * (n : ℝ)) * (n : ℝ) :=
        mul_lt_mul_of_pos_right hC hnPos
      _ = c * (n : ℝ) ^ 2 := by ring
  have hbound := hlog n hnStart
  refine ⟨n, hnN, ?_⟩
  apply (lt_div_iff₀ hnPos).2
  linarith

/-- Generic closure, using the previously compiled denominator argument. -/
theorem irrational_of_three_inputs
    (F : ℕ → Polynomial ℚ) (x A U : ℝ)
    (hdegree : DegreeInput F)
    (hanalytic : AnalyticInput F x U)
    (harithmetic : ArithmeticInput F A)
    (hgap : A + U < 0) : Irrational x := by
  obtain ⟨c, hc, _hcFormula, Q, start, hQ⟩ :=
    three_inputs_quadratic_estimate F x A U hdegree hanalytic harithmetic hgap
  have hDegree : ∀ n : ℕ, start ≤ n → (Q n).natDegree ≤ 37 * n := by
    intro n hn
    exact (hQ n hn).2.1
  have hPositive : ∀ n : ℕ, start ≤ n → 0 < val (Q n) x := by
    intro n hn
    simpa only [int_aeval_eq_val] using (hQ n hn).2.2.1
  have hLog : ∀ n : ℕ, start ≤ n →
      Real.log (val (Q n) x) ≤ -c * (n : ℝ) ^ 2 := by
    intro n hn
    simpa only [int_aeval_eq_val] using (hQ n hn).2.2.2
  exact irrational_of_log_divergence x Q 37 start hDegree hPositive
    (quadratic_log_implies_divergence x Q c hc start hLog)

/-- Explicit exponential output; no exponential-decay premise is assumed. -/
theorem quadratic_estimate_implies_exp_bound
    (F : ℕ → Polynomial ℚ) (x c : ℝ) (h : QuadraticEstimate F x c) :
    ∃ Q : ℕ → Polynomial ℤ, ∃ start : ℕ, ∀ n : ℕ, start ≤ n →
      (Q n).natDegree ≤ 37 * n ∧ 0 < aeval x (Q n) ∧
        aeval x (Q n) ≤ Real.exp (-c * (n : ℝ) ^ 2) := by
  obtain ⟨Q, start, hQ⟩ := h
  refine ⟨Q, start, ?_⟩
  intro n hn
  obtain ⟨_hmultiple, hdegree, hpos, hlog⟩ := hQ n hn
  refine ⟨hdegree, hpos, ?_⟩
  have hexp := Real.exp_le_exp.mpr hlog
  simpa only [Real.exp_log hpos] using hexp

/-- The actual endpoint. F is FIXED by its determinant definition and x is
FIXED to the real part of Mathlib's riemannZeta 7. Four visible arguments:
three mathematical blocks, plus the necessary strict gap. -/
theorem ZETA7_SAME_ARCHITECTURE_CONDITIONAL
    (A U : ℝ)
    (DEGREE_PREMISE : DegreeInput ZetaSevenCandidate.F)
    (ANALYTIC_PREMISE : AnalyticInput ZetaSevenCandidate.F zetaSeven U)
    (ARITHMETIC_PREMISE : ArithmeticInput ZetaSevenCandidate.F A)
    (GAP_PREMISE : A + U < 0) :
    Irrational zetaSeven := by
  exact irrational_of_three_inputs ZetaSevenCandidate.F zetaSeven A U
    DEGREE_PREMISE ANALYTIC_PREMISE ARITHMETIC_PREMISE GAP_PREMISE

/-- Regression guard: the earlier proposed constants do NOT supply the gap.
This proves arithmetic about the constants, not any bound for the candidate. -/
theorem previously_proposed_margin_positive :
    (0 : ℝ) < (44617 / 19200 : ℝ) - 2733991 / 2000000 := by
  norm_num

theorem previously_proposed_margin_exact :
    (44617 / 19200 : ℝ) - 2733991 / 2000000 = 11481679 / 12000000 := by
  norm_num

end ZetaSevenArchitecture
