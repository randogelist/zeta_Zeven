# v0.1.2: explicit natural-to-rational positivity transport

## Reported failure

ZetaSevenNormalization.lean:64:2:

    mod_cast has type (0 : ℕ) < d n
    but is expected to have type (0 : ℚ) < (fun n => ↑(d n)) n

## Proof-body patch

Replace:

    exact_mod_cast (hspec n).1

with:

    change (0 : ℚ) < (d n : ℚ)
    exact (Nat.cast_pos (α := ℚ)).mpr (hspec n).1

`change` reduces the lambda application in the goal. The explicit type parameter
on Nat.cast_pos chooses rational positivity, rather than relying on tactic cast
normalization. Its input remains the existing fact `(hspec n).1`.

No hypothesis, witness, conclusion, candidate definition, or import changes.
The four modules reported PASS by the user are byte-identical to v0.1.1.
ZetaSevenReducedClosure.lean is unchanged and still pending compilation.
Audit.lean gains two matching regression examples; these are not claimed to
have passed before a new Lean run.

---

# v0.1.1: explicit constant-polynomial degree proofs

## Reported failure

ZetaSevenDegree.lean:48:4 in v0.1.0:

    j : Nat
    |- (C (j)^(-1) * C 2^(-1)).natDegree <= 1

The source at that point is the degree bound for C(1/(2*j)). A plain `simp`
rewrites the rational scalar and distributes C across the product. The patch
limits simplification to natDegree_C, which states natDegree(C(q)) = 0 for
every scalar q, including zero. No assumption j > 0 is added.

## Patch

    simpa only [Polynomial.natDegree_C] using (Nat.zero_le 1)

The same explicit step is used for the two other constant-degree leaves.
No candidate definition, theorem signature, assumption, or import is changed.

Two regression examples in Audit.lean cover both the source expression and
the residual product expression printed by Lean.

## Verification boundary

The user-verified Criterion, Candidate, and Architecture sources are preserved
byte-for-byte. The normalization and reduced endpoint sources are likewise
unchanged, but their compilation was not reached in the user's failed run.
This revision has not been Lean-compiled in the assistant container. A passing
run.cmd and its printed axiom audit remain the required verification.
