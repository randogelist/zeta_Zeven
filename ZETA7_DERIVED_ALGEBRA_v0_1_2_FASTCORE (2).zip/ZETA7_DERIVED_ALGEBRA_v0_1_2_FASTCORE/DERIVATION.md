# Independent algebraic derivations for the fixed candidate

These proofs concern the unchanged F defined in ZetaSevenCandidate.lean,
with K=40n, N=3n, h=37n, and kernel D_N^6/D_K.

## Degree

The output of muX is a constant plus a finite sum of constant multiples of
poleValue7(j). Each poleValue7(j) is affine in X. Hence every matrix entry has
natural degree at most one. By the Leibniz determinant expansion, each product
term has degree at most h and its sign does not change degree. A finite sum
cannot increase the maximum degree. Therefore

    natDegree(delta_n) <= h = 37n.

Since F_n = C(S_n)*delta_n, natDegree(F_n) <= 37n.
This proves exactly DegreeInput; an exact degree formula is unnecessary.
No claim that delta_n is nonzero is needed for this inequality.

## Positivity of the factorial scalar

All factorials are positive, as is 4. Every power and every finite product in
S_n is positive. Its denominator is therefore nonzero and S_n>0, including n=0.
This does NOT prove positivity of F_n(zeta(7)).

## Integer normalization existence

For a monomial c X^k with c in Q, let d=den(c)>0 and Q=num(c) X^k in Z[X].
Then map(Q)=C(d)*c X^k.

If map(P)=C(a)*p and map(Q)=C(b)*q with a,b positive integers, then

    map(C(b)*P+C(a)*Q) = C(ab)*(p+q).

Induction on finite polynomial sums proves positive denominator clearing for
any rational polynomial. Applied independently to F_n, classical choice gives
fixed sequences m_n>0, Q_n in Z[X] satisfying map(Q_n)=C(m_n)*F_n for all n.
An explicit alternative is the product of the nonzero coefficient denominators;
no growth bound for this product follows merely from finiteness.

Injectivity of Z -> Q and nonzero scalar multiplication show

    natDegree(Q_n) = natDegree(F_n) <= 37n.

## Reduced conditional endpoint

Supply only the old AnalyticInput(F,zeta7,U), ArithmeticInput(F,A), and A+U<0.
The new degree_input theorem supplies the formerly assumed DegreeInput.
The existing combination theorem then gives, for delta=-(A+U)>0,

    0 < Q_n(zeta7) <= exp(-800*delta*n^2)

for sufficiently large n, and the compiled integer-polynomial contradiction
implies Irrational zetaSeven.

No favorable A,U pair is established here. Existence of normalizers is not
asymptotic control of normalizers.
